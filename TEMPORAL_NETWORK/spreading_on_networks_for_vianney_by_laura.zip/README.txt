This code in C++ implements an SIS epidemic model (S->I infection and I->S recovery without immunity) 
The spread occurs over an empirical temporal contact network which is saved in the .txt file