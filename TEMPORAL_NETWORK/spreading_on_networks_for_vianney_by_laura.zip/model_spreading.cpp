// THIS IS A CODE FOR AN SIS model
// individuals are either in S or in I


//Libraries
#include <iostream>
#include <cmath>
#include <string>
#include <random>
#include <algorithm> 
#include <vector>
#include <iterator>
#include <ctime>
#include <fstream> 
#include <numeric> 

// definition of variables and structures
typedef unsigned int unint;
typedef unsigned int NODE;
typedef std::vector<NODE> NODES; // list of nodes
typedef std::vector<bool> BOOLS;
typedef unsigned int WEEK ;
typedef unsigned int WEIGHT;

// struttura per un contatto
struct CONTACT {NODE i; NODE j; WEIGHT w;}; 

//WEEK goes from 1 to 11
//GIORNI DI CAMBIO BATTERIA: numero di contatti molto basso, giorni 55 e 74, sono stati ESCLUSI
//eliminare giorni 1,2,3 (picco innaturale nel numero di contatti): sono stati ESCLUSI
//eliminare le ultime TRE SETTIMANE (pochissimi contatti)
//arrivare fino al giorno 87 compreso: ARRIVO FINO AL GIORNO 82 (-3-2=77=11SETTIMANE)

typedef std::vector<CONTACT> CONTACTS; // vettore di contatti --> una rete
typedef std::vector<CONTACTS> TEMP_CONTACTS; // vettore di reti --> reti temporali
//I have 11 WEEKLY temporal networks

struct INF_CONTACT {NODE n; WEIGHT w;}; //an infectious contact
                                        //this is a list of susceptible nodes in contact with infectios nodes
                                        //WITH THE ASSOCIATED WEIGHT

typedef std::vector<INF_CONTACT> INF_CONTACTS; // vector of INF_contact

typedef float PROB;
typedef std::vector<PROB> PROBS;
typedef float RATE;
typedef std::vector<RATE> RATES;

unint N = 570;  // number of nodes
unint T_data = 11; // number of contact networks

const unint n_runs = 500; //number of runs
char inputname[200], outputname[200]; // characters for the file names of model outputs

bool hom_scenario = true; //true
bool update = false;

// generator, seed and distributions for random sampling
std::random_device rd;
std::mt19937 generator(rd());

std::uniform_real_distribution<float> unif(0.0,1.0); // uniform distribution between 0 and 1

unint min = 0;
unint max = N-1;
std::uniform_int_distribution<int> randint(min,max); // uniform integer distibution between 0 and N-1

// to read input and save outputs
std::ifstream input;
std::ofstream output;

// function loadData to read the input of the temporal network
TEMP_CONTACTS loadData(char *inputname)
{
    // Define list of contact lists and list of nodes, etc.
    std::string line;
    WEEK week;
    WEIGHT weight;
    NODE node_i,node_j;
    NODES nodes;
    TEMP_CONTACTS temp_network;
    CONTACTS contactList;
    CONTACT contact;

    // Read first line of inputfile as list of characters and get t,i,j:
    // getline skips first line fo text file, hence I added a fake first line
    input.open(inputname);
    getline(input,line);
    input>>node_i>>node_j>>week>>weight;

    // Loop over tt and create list of contact lists:
    for(unint tt=1; tt<=T_data; tt++)
    {
        while(week==tt && !input.eof())
        {
            contact.i=node_i; contact.j=node_j;   // feed contact with the info just read
            contact.w=weight;
            contactList.push_back(contact); //add contact to the contact list

            // Read line and get t,i,j:
            getline(input,line);
            input>>node_i>>node_j>>week>>weight;
        }
        temp_network.push_back(contactList); // add the contact list (one newtork) to the list of temporal networks
        contactList.clear(); //re-initialize contact list
    }
    input.close();
    return temp_network;
}

//model parameters
float shape = 0.619;
float theta = 238.038;
float left_integr = 0.07781418203194258;
float right_integr = 0.016194374719642208;

float tau_medio = 126.957; 
float tau_medio2 = shape*theta;
RATE mu_eff = 1/(float)tau_medio2;

float pi = 3.14159;

float true_f(float mu)
{
    return sin(pi*shape)*(1/mu)*pow(theta*mu-1,-shape)/pi;
}

float eps = 1e-5;
float M = true_f(1/theta + eps);

std::uniform_real_distribution<float> unifxx(1/theta+eps,1);
std::uniform_real_distribution<float> unifyy(0.0,M);

// function to sample a recovery rate for each node
RATE sample_rate()  //passo per reference 
{
  float C = pow(eps,1-shape)/(1-shape);

  float u;
  float v;
  float x;
  float y;
  RATE mu;
  int c;

  u = unif(generator);
  v = unif(generator);

  if(u<=left_integr)
  {
    mu = pow(C*(1-shape)*v,1/(1-shape))+1/theta;
  }
  else if (u<=(left_integr+right_integr))
  {
    mu = 1/(pow(1-v, 1/shape));
  }
  else
  {
    c=0;
    while(c<1)
    {
      x = unifxx(generator);
      y = unifyy(generator);
      if (y <= true_f(x))
      {
        mu = x;
        c = 1;
      }
    }
  }  
  return mu;  //returns recovery rate
}

//function to compute the average of an array
float average(float a[], unint n) 
{ 
    // Find sum of array element 
    int sum = 0; 
    for (int i=0; i<n; i++) 
      sum += a[i]; 
  
    return (sum/n); 
}

const int num_lambda = 1; //explore different values for lambda


// MAIN CODE for simulating spread
int main(int argc, char *argv[])
{
    TEMP_CONTACTS weekly_temp_network;

    sprintf(inputname,"%s","I-BIRD_week.txt"); // file txt with temporal network data
    weekly_temp_network = loadData(inputname);  // load data of the temporal network

    int period = weekly_temp_network.size();

    float lambdas[num_lambda] = {0.2};
    unint Ts[num_lambda] = {2250};

    for (int f = 0; f<num_lambda; f++)   // for different value of the transmission rate lambda
    {
        RATE lambd = lambdas[f];

        PROB prob_rec = mu_eff;  // probability of recovery
        PROB prob_trans = lambd;  // probability of transmission
        PROB weighted_prob; //weighted probability of transmission = lambd*[W/(tot_seconds in a week)]

        PROB homog = prob_rec;
        RATES rec_probs;

        unint T_simul= Ts[f]; 

        float last_values[100];
        unint tbar  = T_simul - 100;
        unint q = 0; //contatore per calcolare average

        // define different variables
        NODE i,j;
        WEIGHT w;
        NODES infected; //list of infected nodes
        BOOLS isInfected; //list which nodes are infected
        unint I; //number of infected nodes
        unint SI; //number of susceptible nodes in contact with infectious nodes
        NODES si_s; //list of susceptible nodes in contact with infectios nodes
        INF_CONTACT inf_contact;
        INF_CONTACTS inf_contacts;   //list of susceptible nodes in contact with infectious nodes
                                    //WITH THE ASSOCIATED WEIGHT
        unint t; //time counter
        NODES::iterator node_iterator;
        CONTACTS::iterator contact_iterator;
        INF_CONTACTS::iterator inf_contact_iterator;

        std::vector<float> I_eq;
        
        //Run simulations
        std::clock_t start = std::clock(); 

        float x;
        float y;

        // name of output file
        if (hom_scenario)
        {
            sprintf(outputname,"l=%.4f,hom.txt", lambd);
            output.open(outputname);  
        }
        else
        {
            if (update)
            { 
                sprintf(outputname,"l=%.4f,pop.txt", lambd);
                output.open(outputname);  
            }
            else 
            {
                sprintf(outputname,"l=%.4f,host.txt", lambd);
                output.open(outputname);  
            }
        }
        
        // Initial conditions
        // Contact networks 
        CONTACTS contactList;

        rec_probs.assign(N,homog);  // assign recover probability to nodes

        for (int s=0; s<n_runs; s++) // we perform different independent runs
        {
            t = 0;

            if (!hom_scenario)
            {
                for (int i=0; i<N; i++)
                {
                    RATE mu = sample_rate();
                    PROB mu_i = mu;
                    rec_probs[i]= mu_i;
                }
            }

            // I have a vector (called isInfected) with length equal to the number of the nodes
            // at each position of the vector ther is a boolean which can either be False (i.e. susceptible) or True (i.e. infected)
            // we start with all nodes susceptible
            isInfected.assign(N,false);
            infected.clear();

            // Initial infected people (randomly selected)
            // Choose a number of seeds and make it infected
            I = 5; // number of initial infected
            //std::cout << "Initial infected" << std::endl;
            for (int i=0; i<I; i++)
                {
                    NODE node = randint(generator); // choose a random node
                    isInfected[node]=true; // make it infetced (update their status)
                }
            //randint may generate the same node more than once,
            //so we compute again I (it may be 4)
            for (i=0; i<N; i++)
                {
                    if (isInfected[i])
                    {
                        infected.push_back(i);
                    }
                }

            I = infected.size();
            output << I << "\t";

            contactList = weekly_temp_network[0];  //start with the first instance of the temporal network
            
            t++;

            
            while(t<T_simul) // for every time step up to T_simul
            {
                //std::cout << "Susceptible at risk:" << std::endl;
                for (contact_iterator=contactList.begin(); contact_iterator!=contactList.end(); contact_iterator++) //iterate on the list of contacts to find the contacts between a susceptible and an infected individual, and put the suscpetible node in inf_contact (i.e. suscpetible nodes at risk)
                {
                    i=(*contact_iterator).i;
                    j=(*contact_iterator).j;
                    w=(*contact_iterator).w;
                    if(isInfected[i])
                    {
                        if(!isInfected[j])
                        {
                            si_s.push_back(j);
                            inf_contact.n = j;
                            inf_contact.w = w;
                            inf_contacts.push_back(inf_contact);
                        }
                    }
                    else
                    {
                        if(isInfected[j])
                        {
                            si_s.push_back(i);
                            inf_contact.n = i;
                            inf_contact.w = w;
                            inf_contacts.push_back(inf_contact);
                        }
                    }
                }

                //si_s vector CONTAINS DUPLICATES, and that is fine
                /*if a susceptible node is present twice in the si_s vector,
                that means that it has contact with TWO infected nodes
                hence infection could be trasmitted by TWO possible routes*/ 

                SI=si_s.size();

                // transition S->I
                /*update the status of the susceptible nodes at risk of infection: 
                do they get infected?*/
                for (inf_contact_iterator=inf_contacts.begin(); inf_contact_iterator!=inf_contacts.end(); inf_contact_iterator++)
                {
                    if (isInfected[(*inf_contact_iterator).n]==false)
                    //this condition is needed in order to not count twice a node that gets infected by two infected neighbours
                    {
                        x = unif(generator);
                        weighted_prob = prob_trans*(*inf_contact_iterator).w/(float)604800;
                        if (x <= weighted_prob) 
                        { 
                            //std::cout << *node_iterator << std::endl;
                            isInfected[(*inf_contact_iterator).n]=true;
                            I++;
                        }
                    }
                }

                // transition I->S
                // the infected nodes do not included the newly infections above
                // they are stored in a different vector
                /*update the status of the infected nodes:
                do they recover?*/
                for (node_iterator=infected.begin(); node_iterator!=infected.end(); node_iterator++)
                {
                    y = unif(generator);
                    if (y <= rec_probs[*node_iterator])
                    {
                        isInfected[*node_iterator]=false; 
                        if (update == true) //popbased
                        {
                            RATE mu = sample_rate();;
                            PROB mu_i = mu;
                            rec_probs[*node_iterator] = mu_i;
                        }
                        I--;
                    }
                }

                //Clear infected list and update
                infected.clear();
                //std::cout << "NUOVI INFETTI + INFETTI NON GUARITI" << std::endl;
                for (i=0; i<N; i++)
                {
                    if (isInfected[i])
                    {
                        infected.push_back(i);
                    }
                }
                
                //Clear si_s list
                si_s.clear();
                inf_contacts.clear();

                //Save number of infected
                output << I << "\t";

                if (t>=tbar)
                {
                    last_values[q]=I;
                    q++;
                }

                //Update contact network
                t++; //se tera 0, il nuovo network deve essere  1 = 1%period
                     // se t era 10, il nuovo network deve essere 0 = 11%11
                contactList = weekly_temp_network[t%period];   
            }

            // this is the end of one run of simulation
            // for each run, I compute my outcome of interest
            // in this case I am interested in the prevalence at equilibrium I_eq
            // I save this quantity for this run in a vector

            if (I>0)
            {
                float av = average(last_values, 100);
                I_eq.push_back(av);
            }
            output << std::endl;

            q=0;

            if (s%10==0)
            {
                std::cout << s << std::endl;
                std::cout << "Equilibrium: " << int(average(last_values, 100)) << std::endl;
            }
        }

        // after multiple runs, I compute the average of I_eq accross runs
        
        float mean = accumulate(I_eq.begin(), I_eq.end(), 0.0)/I_eq.size();              
        std::cout << "Average number of infected at equilibrium:" << mean << std::endl;
        std::cout << "Executing Time: " << (( clock() - start ) / (double) CLOCKS_PER_SEC)/60 << " min\n";
        std::cout << "Hom_scenario: " << hom_scenario << std::endl;
        std::cout << "Update: " << update << std::endl;
        std::cout << "Transmission: " << lambd << std::endl; 
        output.close();
    }
    return 0;
}
