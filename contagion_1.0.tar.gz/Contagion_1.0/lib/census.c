/*$Id: census.c,v 1.2 2007/01/25 10:02:10 mcv21 Exp $*/
/*
 * This file is part of the library of graph analysis and disease
 * simulation functions submitted along with the thesis "Spacial Spread
 * of Farm Animal Diseases" for the degree of Doctor of Philosophy at the
 * University of Cambridge. 
 *
 * The library is Copyright (C) 2007 Matthew Vernon <matthew@debian.org>
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program (as gpl.txt); if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */

#include "census.h"

int triad_table[TTSIZE]={T003,T012,T012,T102,T012,T021d,T021c,T111u,
			 T012,T021c,T021u,T111d,T102,T111u,T111d,T201,
			 T012,T021c,T021d,T111u,T021u,T030t,T030t,T120u,
			 T021c,T030c,T030t,T120c,T111d,T120c,T120d,T210,
			 T012,T021u,T021c,T111d,T021c,T030t,T030c,T120c,
			 T021d,T030t,T030t,T120d,T111u,T120u,T120c,T210,
			 T102,T111d,T111u,T201,T111d,T120d,T120c,T210,
			 T111u,T120c,T120u,T210,T201,T210,T210,T300};
