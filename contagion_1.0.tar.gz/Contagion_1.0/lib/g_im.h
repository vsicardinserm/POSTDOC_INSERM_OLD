/*$Id: g_im.h,v 1.6 2007/01/25 10:02:10 mcv21 Exp $*/
/*
 * This file is part of the library of graph analysis and disease
 * simulation functions submitted along with the thesis "Spacial Spread
 * of Farm Animal Diseases" for the degree of Doctor of Philosophy at the
 * University of Cambridge. 
 *
 * The library is Copyright (C) 2007 Matthew Vernon <matthew@debian.org>
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program (as gpl.txt); if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */

#ifndef G_IM_H
#define G_IM_H

#include <stdlib.h>

#include "gens.h"

gtest_fn im_test;
gset_fn im_set;
gsetval_fn im_setval;
gunset_fn im_unset;
giter_fn im_next;
gsort_fn im_sort;
gfree_fn im_free;

extern const struct gennetvtable vtable_for_intmatrix;

struct intmatrix{
  /*This must remain the first element!*/
  struct gennet general;
  int n;
  int **net;
};

#endif /*G_IM_H*/
